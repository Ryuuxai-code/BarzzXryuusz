const { Telegraf } = require("telegraf");
const fs = require('fs');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const path = require("path");
const config = require("./database/config.js");
const axios = require("axios");
const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const { InlineKeyboard } = require("grammy");
const {
  default: makeWASocket,
  makeInMemoryStore,
  useMultiFileAuthState,
  DisconnectReason,
  proto,
  prepareWAMessageMedia,
  generateWAMessageFromContent
} = require('@whiskeysockets/baileys');

const { tokens, owner: OwnerId, ipvps: VPS, port: PORT } = config;
const bot = new Telegraf(tokens);
const app = express();

const sessions = new Map();
const file_session = "./sessions.json";
const sessions_dir = "./auth";
const file = "./database/akses.json";
const userPath = path.join(__dirname, "./database/user.json");
let userApiBug = null;
let sock;

const { extractMessageContent, jidNormalizedUser, proto, delay, getContentType, areJidsSameUser, generateWAMessage } = require("@whiskeysockets/baileys")
const chalk = require('chalk')
const fs = require('fs')
const Crypto = require('crypto')
const axios = require('axios')
const moment = require('moment-timezone')
const { sizeFormatter } = require('human-readable')
const util = require('util')
const { defaultMaxListeners } = require('stream')
const { read, MIME_JPEG, RESIZE_BILINEAR, AUTO } = require('jimp')

const unixTimestampSeconds = (date = new Date()) => Math.floor(date.getTime() / 1000)

exports.unixTimestampSeconds = unixTimestampSeconds

exports.generateMessageTag = (epoch) => {
    let tag = (0, exports.unixTimestampSeconds)().toString();
    if (epoch)
        tag += '.--' + epoch; // attach epoch if provided
    return tag;
}

exports.processTime = (timestamp, now) => {
  return moment.duration(now - moment(timestamp * 1000)).asSeconds()
}

exports.getRandom = (ext) => {
    return `${Math.floor(Math.random() * 10000)}${ext}`
}

exports.getBuffer = async (url, options) => {
  try {
    options ? options : {}
    const res = await axios({
      method: "get",
      url,
      headers: {
        'DNT': 1,
        'Upgrade-Insecure-Request': 1
      },
      ...options,
      responseType: 'arraybuffer'
    })
    return res.data
  } catch (err) {
    return err
  }
}

exports.formatSize = (bytes) => {
const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
if (bytes === 0) return '0 Bytes';
const i = Math.floor(Math.log(bytes) / Math.log(1024));
return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + sizes[i];
};

exports.fetchJson = async (url, options) => {
    try {
        options ? options : {}
        const res = await axios({
            method: 'GET',
            url: url,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
            },
            ...options
        })
        return res.data
    } catch (err) {
        return err
    }
}

exports.runtime = function(seconds) {
  seconds = Number(seconds);
  var d = Math.floor(seconds / (3600 * 24));
  var h = Math.floor(seconds % (3600 * 24) / 3600);
  var m = Math.floor(seconds % 3600 / 60);
  var s = Math.floor(seconds % 60);
  var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
  var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
  var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
  var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
  return dDisplay + hDisplay + mDisplay + sDisplay;
}

exports.clockString = (ms) => {
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}

exports.reSize = async (buffer, x, z) => {
      return new Promise(async (resolve, reject) => {
         var buff = await read(buffer)
         var ab = await buff.resize(x, z).getBufferAsync(MIME_JPEG)
         resolve(ab)
      })
}

exports.sleep = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}

exports.isUrl = (url) => {
    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
}

exports.getTime = (format, date) => {
  if (date) {
    return moment(date).locale('id').format(format)
  } else {
    return moment.tz('Asia/Jakarta').locale('id').format(format)
  }
}

exports.formatDate = (n, locale = 'id') => {
  let d = new Date(n)
  return d.toLocaleDateString(locale, {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    second: 'numeric'
  })
}

exports.tanggal = (numer) => {
  myMonths = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
        myDays = ['Minggu','Senin','Selasa','Rabu','Kamis','Jum’at','Sabtu']; 
        var tgl = new Date(numer);
        var day = tgl.getDate()
        bulan = tgl.getMonth()
        var thisDay = tgl.getDay(),
        thisDay = myDays[thisDay];
        var yy = tgl.getYear()
        var year = (yy < 1000) ? yy + 1900 : yy; 
        const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
        let d = new Date
        let locale = 'id'
        let gmt = new Date(0).getTime() - new Date('1 January 1970').getTime()
        let weton = ['Pahing', 'Pon','Wage','Kliwon','Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]

        return`${thisDay}, ${day} - ${myMonths[bulan]} - ${year}`
}

exports.formatp = sizeFormatter({
    std: 'JEDEC', //'SI' = default | 'IEC' | 'JEDEC'
    decimalPlaces: 2,
    keepTrailingZeroes: false,
    render: (literal, symbol) => `${literal} ${symbol}B`,
})

exports.jsonformat = (string) => {
    return JSON.stringify(string, null, 2)
}

function format(...args) {
  return util.format(...args)
}

exports.logic = (check, inp, out) => {
  if (inp.length !== out.length) throw new Error('Input and Output must have same length')
  for (let i in inp)
    if (util.isDeepStrictEqual(check, inp[i])) return out[i]
  return null
}

exports.generateProfilePicture = async (buffer) => {
  const jimp = await Jimp.read(buffer)
  const min = jimp.getWidth()
  const max = jimp.getHeight()
  const cropped = jimp.crop(0, 0, min, max)
  return {
    img: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG),
    preview: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG)
  }
}

exports.bytesToSize = (bytes, decimals = 2) => {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

exports.getSizeMedia = (path) => {
    return new Promise((resolve, reject) => {
        if (/http/.test(path)) {
            axios.get(path)
            .then((res) => {
                let length = parseInt(res.headers['content-length'])
                let size = exports.bytesToSize(length, 3)
                if(!isNaN(length)) resolve(size)
            })
        } else if (Buffer.isBuffer(path)) {
            let length = Buffer.byteLength(path)
            let size = exports.bytesToSize(length, 3)
            if(!isNaN(length)) resolve(size)
        } else {
            reject('error gatau apah')
        }
    })
}

exports.parseMention = (text = '') => {
    return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

exports.getGroupAdmins = (participants) => {
        let admins = []
        for (let i of participants) {
            i.admin === "superadmin" ? admins.push(i.id) :  i.admin === "admin" ? admins.push(i.id) : ''
        }
        return admins || []
     }

/**
 * Serialize Message
 * @param {WAConnection} conn 
 * @param {Object} m 
 * @param {store} store 
 */
exports.smsg = (nted, m, store) => {
    if (!m) return m
    let M = proto.WebMessageInfo

    if (m.key) {
        m.id = m.key.id || ''
        m.from = m.key.remoteJid
            ? (m.key.remoteJid.startsWith('status')
                ? jidNormalizedUser(m.key?.participant || m.participant || '')
                : jidNormalizedUser(m.key.remoteJid))
            : ''
        m.isBaileys = m.id ? m.id.startsWith('BAE5') && m.id.length === 16 : false
        m.chat = m.key.remoteJid || ''
        m.fromMe = m.key.fromMe || false
        m.isGroup = m.chat.endsWith('@g.us')
        m.sender = nted.decodeJid(
            (m.fromMe && nted.user?.id) ||
            m.participant ||
            m.key.participant ||
            m.chat ||
            ''
        )
        if (m.isGroup) m.participant = nted.decodeJid(m.key.participant || '') || ''
    }

    if (m.message) {
        m.mtype = getContentType(m.message)
        m.msg =
            (m.mtype === 'viewOnceMessage'
                ? m.message[m.mtype].message[getContentType(m.message[m.mtype].message)]
                : m.message[m.mtype]) || {}

        m.body =
            m.message.conversation ||
            m.msg.caption ||
            m.msg.text ||
            (m.mtype === 'listResponseMessage' && m.msg.singleSelectReply?.selectedRowId) ||
            (m.mtype === 'buttonsResponseMessage' && m.msg.selectedButtonId) ||
            (m.mtype === 'viewOnceMessage' && m.msg.caption) ||
            m.text ||
            ''

        let quoted = m.quoted = m.msg?.contextInfo?.quotedMessage || null
        m.mentionedJid = m.msg?.contextInfo?.mentionedJid || []

        if (m.quoted) {
            let type = getContentType(quoted)
            if (!type) return m

            m.quoted = m.quoted[type] || {}
            if (['productMessage'].includes(type)) {
                type = getContentType(m.quoted)
                m.quoted = m.quoted[type] || {}
            }
            if (typeof m.quoted === 'string') m.quoted = { text: m.quoted }

            m.quoted.key = {
                remoteJid: m.msg?.contextInfo?.remoteJid || m.from,
                participant: jidNormalizedUser(m.msg?.contextInfo?.participant || m.sender || ''),
                fromMe: areJidsSameUser(
                    jidNormalizedUser(m.msg?.contextInfo?.participant || ''),
                    jidNormalizedUser(nted?.user?.id || '')
                ),
                id: m.msg?.contextInfo?.stanzaId || ''
            }

            m.quoted.mtype = type
            m.quoted.id = m.msg?.contextInfo?.stanzaId || ''
            m.quoted.chat = m.msg?.contextInfo?.remoteJid || m.chat
            m.quoted.from = /g\.us|status/.test(m.quoted.chat)
                ? m.quoted.key.participant
                : m.quoted.key.remoteJid
            m.quoted.isBaileys = m.quoted.id
                ? m.quoted.id.startsWith('BAE5') && m.quoted.id.length === 16
                : false
            m.quoted.sender = nted.decodeJid(m.msg?.contextInfo?.participant || m.sender || '')
            m.quoted.fromMe = m.quoted.sender === (nted.user && nted.user.id)
            m.quoted.text =
                m.quoted.text ||
                m.quoted.caption ||
                m.quoted.conversation ||
                m.quoted.contentText ||
                m.quoted.selectedDisplayText ||
                m.quoted.title ||
                ''
            m.quoted.mentionedJid = m.msg?.contextInfo?.mentionedJid || []

            m.getQuotedObj = m.getQuotedMessage = async () => {
                if (!m.quoted.id) return false
                let q = await store.loadMessage(m.chat, m.quoted.id, nted).catch(() => null)
                return exports.smsg(nted, q || {}, store)
            }

            let vM = m.quoted.fakeObj = M.fromObject({
                key: {
                    remoteJid: m.quoted.chat,
                    fromMe: m.quoted.fromMe,
                    id: m.quoted.id
                },
                message: quoted,
                ...(m.isGroup ? { participant: m.quoted.sender } : {})
            })

            m.quoted.delete = () => nted.sendMessage(m.quoted.chat, { delete: vM.key })
            m.quoted.copyNForward = (jid, forceForward = false, options = {}) =>
                nted.copyNForward(jid, vM, forceForward, options)
            m.quoted.download = () => nted.downloadMediaMessage(m.quoted)
        }
    }

    if (m.msg?.url) m.download = () => nted.downloadMediaMessage(m.msg)

    m.text =
        m.msg?.text ||
        m.msg?.caption ||
        m.message?.conversation ||
        m.msg?.contentText ||
        m.msg?.selectedDisplayText ||
        m.msg?.title ||
        ''

    m.reply = (text, chatId = m.chat, options = {}) =>
        Buffer.isBuffer(text)
            ? nted.sendMedia(chatId, text, 'file', '', m, { ...options })
            : nted.sendText(chatId, text, m, { ...options })

    m.copy = () => exports.smsg(nted, M.fromObject(M.toObject(m)))
    m.copyNForward = (jid = m.chat, forceForward = false, options = {}) =>
        nted.copyNForward(jid, m, forceForward, options)

    return m
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright(`Update ${__filename}`))
  delete require.cache[file]
  require(file)
})

// ==================== HTML EXECUTION ==================== //
const executionPage = (
  status = "🟥 Ready",
  detail = {},
  isForm = true,
  userInfo = {},
  message = "",
  mode = ""
) => {
  const { username, expired } = userInfo;
  const formattedTime = expired
    ? new Date(expired).toLocaleString("id-ID", {
        timeZone: "Asia/Jakarta",
        year: "2-digit",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "-";

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>X-ATHENA V1</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <style>
    :root {
      --neon-main: #a21caf;
      --neon-secondary: #c084fc;
      --neon-glow: #d946ef;
      --card-bg: rgba(28, 0, 45, 0.95);
      --glass-bg: rgba(24, 0, 40, 0.85);
      --white: #fff;
      --accent: #a21caf;
      --shadow: 0 0 30px 2px #a21caf99;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Orbitron', sans-serif;
      background: #000;
      min-height: 100vh;
      color: var(--white);
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
      /* Neon animated overlay */
      position: relative;
      overflow: hidden;
    }
    body::before {
      content: "";
      position: fixed;
      inset: 0;
      pointer-events: none;
      background:
        radial-gradient(circle at 30% 20%, #a21caf55 0%, transparent 60%),
        radial-gradient(circle at 80% 80%, #c084fc44 0%, transparent 65%),
        radial-gradient(circle at 60% 30%, #f0abfc33 0%, transparent 65%);
      z-index: 0;
      animation: neonGlowBg 7s linear infinite alternate;
      opacity: 0.9;
    }
    @keyframes neonGlowBg {
      to {
        background:
          radial-gradient(circle at 22% 30%, #d946ef77 0%, transparent 60%),
          radial-gradient(circle at 77% 70%, #c084fc77 0%, transparent 65%),
          radial-gradient(circle at 60% 47%, #a21caf77 0%, transparent 60%);
      }
    }
    .container {
      background: var(--glass-bg);
      border: 1.5px solid var(--neon-main);
      padding: 28px 24px;
      border-radius: 22px;
      max-width: 420px;
      width: 100%;
      box-shadow: 0 0 28px 4px var(--neon-glow), 0 0 0 2px #fff1 inset;
      backdrop-filter: blur(12px);
      z-index: 2;
      position: relative;
      animation: fadeIn 1.2s cubic-bezier(0.4,0.2,0.4,1);
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(40px) scale(0.95); }
      to { opacity: 1; transform: none; }
    }
    .logo {
      width: 80px;
      height: 80px;
      margin: 0 auto 12px;
      display: block;
      border-radius: 50%;
      box-shadow: 0 0 30px 6px var(--neon-glow);
      object-fit: cover;
      border: 2px solid var(--neon-secondary);
      filter: brightness(1.12) saturate(1.2);
    }
    .username {
      font-size: 23px;
      font-weight: bold;
      text-align: center;
      margin-bottom: 7px;
      color: var(--white);
      text-shadow: 0 0 10px var(--neon-glow), 0 0 2px #fff;
      letter-spacing: 1px;
    }
    .connected {
      font-size: 15px;
      color: #0afc67;
      margin-bottom: 18px;
      display: flex;
      justify-content: center;
      align-items: center;
      font-weight: bold;
      letter-spacing: 1.5px;
      text-shadow: 0 0 8px #12e07a88;
    }
    .connected::before {
      content: '';
      width: 10px;
      height: 10px;
      background: #00ff5e;
      border-radius: 50%;
      display: inline-block;
      margin-right: 8px;
      box-shadow: 0 0 7px #13ff8c, 0 0 2px #fff;
    }
    input[type="text"] {
      width: 100%;
      padding: 14px;
      border-radius: 11px;
      background: #180024ee;
      border: 1.5px solid var(--neon-secondary);
      color: var(--white);
      margin-bottom: 17px;
      box-shadow: 0 0 11px var(--neon-glow) inset;
      font-size: 15px;
      font-weight: 500;
      letter-spacing: 1px;
      outline: none;
      transition: border 0.24s, box-shadow 0.21s;
    }
    input[type="text"]:focus {
      border-color: var(--neon-main);
      box-shadow: 0 0 16px var(--neon-glow);
      background: #220035ee;
    }
    /* Dropdown */
    .select-wrapper { margin-bottom: 16px; }
    select {
      width: 100%;
      padding: 14px;
      border-radius: 10px;
      background: #220035f5;
      border: 1.5px solid var(--neon-main);
      color: var(--neon-glow);
      font-weight: bold;
      font-size: 15px;
      text-shadow: 0 0 8px var(--neon-glow), 0 0 2px #fff;
      cursor: pointer;
      appearance: none;
      box-shadow: 0 0 9px var(--neon-glow) inset;
      outline: none;
      transition: border 0.2s, box-shadow 0.19s;
      letter-spacing: 1px;
    }
    select:focus {
      border-color: var(--neon-secondary);
      box-shadow: 0 0 15px var(--neon-glow);
      background: #2c0055ee;
    }
    .execute-button {
      background: linear-gradient(135deg, var(--neon-main), var(--neon-secondary));
      color: var(--white);
      padding: 14px;
      width: 100%;
      border-radius: 12px;
      font-weight: bold;
      border: none;
      margin-bottom: 14px;
      cursor: pointer;
      font-size: 16px;
      text-shadow: 0 0 10px var(--neon-glow), 0 0 2px #fff;
      letter-spacing: 1.2px;
      box-shadow: 0 0 17px 2px var(--neon-glow);
      transition: 0.21s;
      outline: none;
      filter: brightness(1.17);
    }
    .execute-button:disabled {
      background: #240042;
      cursor: not-allowed;
      opacity: 0.5;
      box-shadow: none;
      filter: none;
    }
    .execute-button:hover:not(:disabled) {
      background: var(--neon-secondary);
      box-shadow: 0 0 24px 7px var(--neon-glow), 0 0 5px #fff3;
      filter: brightness(1.24);
    }
    .footer-action-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-items: center;
      gap: 9px;
      margin-top: 22px;
    }
    .footer-button {
      background: rgba(162, 28, 175, 0.15);
      border: 1.2px solid var(--neon-main);
      border-radius: 8px;
      padding: 8px 13px;
      font-size: 14px;
      color: var(--white);
      display: flex;
      align-items: center;
      gap: 6px;
      transition: background 0.24s, box-shadow 0.21s;
      font-weight: 600;
      text-shadow: 0 0 7px var(--neon-glow);
      letter-spacing: 1px;
    }
    .footer-button:hover {
      background: rgba(193, 102, 255, 0.23);
      box-shadow: 0 0 12px var(--neon-glow);
    }
    .footer-button a {
      text-decoration: none;
      color: var(--neon-glow);
      display: flex;
      align-items: center;
      gap: 6px;
    }
    @media (max-width: 500px) {
      .container { padding: 13px 3vw; border-radius: 14px; }
      .logo { width: 50px; height: 50px; }
      .username { font-size: 16px;}
      .footer-button { font-size: 12px; padding: 7px 7px; }
      select, input[type="text"], .execute-button { font-size: 13px; padding: 10px;}
    }
  </style>
</head>
<body>
  <div class="container">
    <img src="https://res.cloudinary.com/shaa/image/upload/v1757339222/shaastore/o35g1v4so0tnczirobmz.jpg" alt="Logo" class="logo" />
    <div class="username">Olá, ${username || 'Anônimo'}</div>
    <div class="connected">CONNECTED</div>

    <input type="text" id="numberInput" placeholder="Please input target number. example : +628xxxxxxx or 628xxxxxxx or +1202xxxxxxx" />

    <div class="select-wrapper">
      <select id="modeSelect">
        <option value="" disabled selected>-- Pilih Mode --</option>
        <option value="andros">X-ATHENA CRASH</option>
        <option value="AndrosDelay">X-ATHENA DELAY</option>
        <option value="ios">X-ATHENA IPHONE</option>
      </select>
    </div>

    <button class="execute-button" id="executeBtn" disabled>
      <i class="fas fa-moon"></i> EXECUTE
    </button>

    <div class="footer-action-container">
      <div class="footer-button developer">
        <a href="https://t.me/X4thena" target="_blank">
          <i class="fab fa-telegram"></i> Developer
        </a>
      </div>
      <div class="footer-button logout">
        <a href="/logout">
          <i class="fas fa-sign-out-alt"></i> Logout
        </a>
      </div>
      <div class="footer-button user-info">
        <i class="fas fa-user"></i> ${username || 'Desconhecido'}
        <span style="color:#c084fc; font-weight:bold;">&nbsp;•&nbsp;</span>
        <i class="fas fa-hourglass-half"></i> ${formattedTime}
      </div>
    </div>
  </div>

  <script>
  const inputField = document.getElementById('numberInput');
  const modeSelect = document.getElementById('modeSelect');
  const executeBtn = document.getElementById('executeBtn');

  function isValidNumber(number) {
    const pattern = /^\\+?\\d{7,20}$/;
    return pattern.test(number);
  }

  function toggleButton() {
    const number = inputField.value.trim().replace(/\\s+/g, '');
    const selectedMode = modeSelect.value;
    executeBtn.disabled = !(isValidNumber(number) && selectedMode);
  }

  inputField.addEventListener('input', toggleButton);
  modeSelect.addEventListener('change', toggleButton);

  executeBtn.addEventListener('click', () => {
    const number = inputField.value.trim().replace(/\\s+/g, '');
    const selectedMode = modeSelect.value;
    window.location.href = '/execution?mode=' + selectedMode + '&target=' + encodeURIComponent(number);
  });

  toggleButton();
  </script>
</body>
</html>`;
};