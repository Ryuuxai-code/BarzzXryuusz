module.exports = {
  tokens: "8262700840:AAE7ivDdl0mDA3BFfITogDQCJXI_6Ac5Qww",  // Ubah Jadi Token Bot Mu !!!
  owner: "8158988039", // Ubah Jadi Id Mu !!!
  port: "5036", // Ubah Jadi Port Panel Mu !!!
  ipvps: "-" // Ubah Jadi Ip Vps Mu !!!
};